﻿using Microsoft.EntityFrameworkCore;

namespace Hemkop.Models
{

    //Klassen VaraContext kommer ärva från DbContext som är en klass som har installerats via NuGet Package Manager. 
  
    public class VaraContext : DbContext
    { 
        //Så att databasen har en tabell som heter Varor som ska innehålla värdena i modellen Vara. 
        public DbSet<Vara> Varor { get; set; }
        public VaraContext()
        {
            //Genväg som gör att DbContext kollar att det finns en sådan databas.
            Database.EnsureCreated();
        }
        //OnConfiguring är en funktion som finns i DbContext.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //För att Sqlite (fildatabasen) ska användas på uppstartskommandot (klassen DbContextOptionsBuilder).
            object value = optionsBuilder.UseSqlite("Data Source=varaData.db");
        }
    }
}
