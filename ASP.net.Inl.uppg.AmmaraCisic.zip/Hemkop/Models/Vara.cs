﻿//Model är en klass som beskriver datan man vill ha, vilket görs nedan.
namespace Hemkop.Models
{
    //Här skapas modellen Vara och vilka properties den ska ha. 
    public class Vara
    {
        //Int för att id och pris utgörs av heltal, string för att resterande properties utgörs av text.
        //Get och set tillhör syntaxen tll en property. 
        public int Id { get; set; }
        public string Varunamn { get; set; }

        public string Innehåll { get; set; }

        public string Tillverkningsland { get; set; }

        public int Pris { get; set; }

    }
}
