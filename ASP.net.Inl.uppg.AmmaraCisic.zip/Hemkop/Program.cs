using Microsoft.AspNetCore.Authentication.Cookies;
//Cookies f�r att veta vilken anv�ndare det �r som �r inloggad, n�r man �r inloggad har man en cookie som kommer ih�g det (kommentar tillh�r raden ovanf�r).
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

//Talar om att cookies ska anv�ndas och options talar om n�r man g�r cookies var inloggningssidan finns. 
//Options.LoginPath-raden: f�r att f� upp loginruta n�r man ej �r inloggad. Ska g� till controllern User och metoden Index.
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options => { options.LoginPath = "/User/Index/"; });


var app = builder.Build();


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();  
app.UseStaticFiles();

app.UseRouting();

//St�d f�r loginfunktionen. Viktigt att den st�r f�re authorization nedan!
//Authentication: inlog-funktionen och kontroll av inloggning med cookies, l�senord m.m. Aktiverar inloggningsfunktionen.
app.UseAuthentication();

//Inneb�r att alla ska inte kunna f� komma �t allting. Fungerar som en l�smekanism.
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();  
