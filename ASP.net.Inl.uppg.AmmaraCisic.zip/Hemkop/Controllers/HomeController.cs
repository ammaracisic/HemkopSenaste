﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


//Controller för landningssidan (alltså startcontroller) och innehåller en indexssida. När action index sedan tillämpas så returneras vyn index som ligger i mappen Home. 
namespace Hemkop.Controllers
{
    //Home = startfunktionen
    //Index = startmetoden
 
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

    }
}
  