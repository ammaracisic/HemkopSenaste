﻿using Hemkop.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hemkop.Controllers
{

    public class AdminController : Controller
    {
        //Authorize= ser till att bara rätt användare kommer in (om man vill ändra eller radera en vara eller lägga till en ny vara) och går bara att komma in om man är inloggad.
        [Authorize]
        //Indexsidan för när man är inloggad som admin.
        public IActionResult Index()
        {
            using (VaraContext db = new VaraContext())
            {
                //Lista skapas med varor från databasen som sedan visas. 
                List<Vara> varulista = db.Varor.ToList();

                return View(varulista);
            }
        }

        //Här kommer man till vyn create som finns i mappen varor och visas sedan. 
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        //Här skapas den nya varan som sedan läggs till i databasen och sparas. Efter att den nya varan skapats så skickas man tbx till indexsidan. 
        public IActionResult Create(Vara nyVara)
        {
            using (VaraContext db = new VaraContext())
                //För att förhindra error-meddelande om man inte fyller i information för ny vara, detta m.h.a null-check. 
                if (nyVara.Tillverkningsland != null)
                {
                    db.Varor.Add(nyVara);
                    db.SaveChanges();
                }
            
            return RedirectToAction("Index");
        }

        //Här går man in på detaljer om en specifik vara m.h.a varans id som hämtas från databasen som sedan returnerar vyn vara (som är en model). Alltså när sidan detaljer anropas så ska det alltid få med sig ett id,därav int id
        public IActionResult Detaljer(int id)
        {
            using (VaraContext db = new VaraContext())
            {
                Vara vara = db.Varor.Find(id);
                return View(vara);
            }
        }

        //Varan hittas m.h.a varans id och då kan man ändra info om denna varan.
        public IActionResult Edit(int id)
        {
            using (VaraContext db = new VaraContext())
            {
                Vara vara = db.Varor.Find(id);
                return View(vara);
            }
        }

        //Här uppdateras och sparas ändring av info som gjorts för en vara och sedan skickas man tillbaka till index-sidan. 
        [HttpPost]
        public IActionResult Edit(Vara vara)
        {
            using (VaraContext db = new VaraContext())
            {
                db.Update(vara);
                db.SaveChanges();

                return RedirectToAction("Index");
            }
        }
        //Här hittas en vara m.h.a dess id från databasen och sedan returneras vyn vara. 
        public IActionResult Delete(int id)
        {
            using (VaraContext db = new VaraContext())
            {
            
                    Vara vara = db.Varor.Find(id);
                    return View(vara);
                

               
            }
        }
        //Här raderas den specifika varan och ändringen sparas. Sedan skickas man till index-sidan. 
        [HttpPost]
        public IActionResult Delete(Vara vara)
        {
            using (VaraContext db = new VaraContext())
            { 
              
                    db.Varor.Remove(vara);
                    db.SaveChanges();
                
                
                   
            
                    return RedirectToAction("Index");

            }
        }

        //Logga ut. När användaren loggar ut omdirigeras den till index home. 
        public async Task<IActionResult> SignOutuser()
        {
            await HttpContext.SignOutAsync(
                CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }
    }
}

