﻿using Hemkop.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Hemkop.Controllers
{
    //Klassen VarorController ärver egenskaper från controller. Action index använder sig av modellen VaraContext som används i databasen db. En lista skapas utifrån Vara som heter Varulista som läggs till i databasen.
    //När man är inne i index så returneas vyn varulista. 
   
    public class VarorController : Controller
    {
        //IActionResult=att en sida ska visas upp, i detta fall index.
        public IActionResult Index()
        {
            //GÖr att man kopplas till databasen, hämtar listan med varor och visar upp det på sidan.
            using (VaraContext db = new VaraContext())
            {
                //Med dbContext anropas tabellen varor och hämtar lista av varorna och skickas till vyn.
                List<Vara> varulista = db.Varor.ToList();
                  
                return View(varulista);
            }  
        }

        //Här skapas vyn create som finns i mappen varor och som visar vyn create. 
        [HttpGet]
        
        public IActionResult Create()
        {
            return View();
        }

        //Ny vara skapas (som heter nyVara) och läggs in i databasen samt sparas med SaveChanges. När detta är gjort så skickas man till index-sidan. 
        [HttpPost]
        public IActionResult Create(Vara nyVara)
        {
            using (VaraContext db = new VaraContext())
            {
                db.Varor.Add(nyVara);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        //Här går man in på detaljer om en specifik vara m.h.a varans id som hämtas från databasen som sedan returnerar vyn vara (som är en model). Alltså när sidan detaljer anropas så ska det alltid få med sig ett id,därav int id
        public IActionResult Detaljer(int id)
        {
            using (VaraContext db = new VaraContext())
            {
                Vara vara = db.Varor.Find(id);
                return View(vara);
            }
        }

      
      
    }
}
