﻿using Hemkop.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Hemkop.Controllers
{
    public class UserController : Controller
    {
        //ReturnUrl = omdirigera användaren till begärd sida (index) efter inlogg.
        public IActionResult Index(string returnUrl = "")
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }
      

        //Async-metoden kan ej skicka tbx vyn om den ej är inkapslad i en task. Ligger o väntar på att det ska bli klart för att sedan skickas iväg. 
        //
        [HttpPost]
        public async Task<IActionResult> Index(UserModel userModel, string returnUrl ="")
        {

            //Kollar inloggningen
            //Anropar metoden CheckUser och skickar dit userModel som då innehåller användarnamn och lösenord där svaret sedan fås i variabeln validUser.
            bool validUser = CheckUser(userModel);
            //If-sats: om funktionen CheckUser uppfyller "true".
            if (validUser == true)
            {
                //Om allt stämmer så ska användaren loggas in med sitt användarnamn.
                var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme);
                identity.AddClaim(new Claim(ClaimTypes.Name, userModel.UserName));

                //Metoden SignInAsync innebär att den är beredd på att inloggningen kan ta tid och då vill den ej låsa systemet (m.h.a kommandot await). 
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

                //Om returnUrl finns så ska användaren skickas till returnUrl.
                //Annars omdirigeras till index admin.
                if (returnUrl != "")

                    return Redirect(returnUrl);
                else
                    return RedirectToAction("Index", "Admin");
            }
            //Om det ej är rätt användare (valid user) så dyker ett "varnings"meddelande upp.
            else
            {
                ViewBag.ErrorMessage = "Inloggningen ej godkänd, korrekt användarnamn och lösenord krävs";
                ViewData["ReturnUrl"] = returnUrl;
                return View();
            }
        }
        
        //Funktion som kollar om det är rätt användare,dvs om användare har rätt inloggningsuppgifter.
        private bool CheckUser(UserModel userModel)
        {
            {
                //Nu blir användarnamn och lösen hårdkodat pga ok i detta fall. Annars ska man helst undvika det pga säkerhetsbrist!
                //ToUpper: det som skrivits in omvandlas till stora bokstäver.
                //Nedanstående rad: inlogg OK om användarnamn och lösenord inte är tomma samt om de fylls i med rätt användarnamn (ADMIN) och lösen (pwd). Annars dyker ett error-meddelande upp dvs,
                //"Inloggningen ej godkänd, korrekt användarnamn och lösenord krävs".
                if (userModel.UserName != null && userModel.UserName.ToUpper() == "ADMIN" && userModel.Password == "pwd" )
                {
                    return true;

                }
                else
                {
                    return false;
                       

                }

         





            }  
        }
       
       

    }
}
